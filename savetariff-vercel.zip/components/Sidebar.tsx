"use client";
import { useEffect, useState } from "react";
import { Plus, Trash2, Edit2 } from "lucide-react";

type Convo = { id: string; title: string; updatedat: string };

export default function Sidebar({ selected, onSelect, clientId }:
  { selected?: string; onSelect: (id: string)=>void; clientId: string; }) {

  const [list, setList] = useState<Convo[]>([]);

  async function load() {
    const res = await fetch(`/api/conversations?clientId=${clientId}`);
    const data = await res.json();
    setList(data);
  }
  useEffect(() => { load(); }, [clientId]);

  async function createNew() {
    await fetch(`/api/conversations?clientId=${clientId}`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title: "New conversation" })
    });
    await load();
  }
  async function rename(id: string) {
    const title = prompt("Rename conversation");
    if (!title) return;
    await fetch(`/api/conversations/${id}?clientId=${clientId}`, {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title })
    });
    await load();
  }
  async function del(id: string) {
    if (!confirm("Delete this conversation?")) return;
    await fetch(`/api/conversations/${id}?clientId=${clientId}`, { method: "DELETE" });
    await load();
    if (selected === id && list.length) onSelect(list[0]?.id);
  }

  return (
    <aside className="w-full sm:w-72 border-r border-brand-border bg-white h-full flex flex-col">
      <div className="p-3 border-b border-brand-border flex items-center justify-between">
        <div className="font-semibold text-brand-navy">Conversations</div>
        <button onClick={createNew} className="btn btn-outline text-xs inline-flex items-center gap-1 px-2 py-1">
          <Plus className="w-3.5 h-3.5" /> New
        </button>
      </div>
      <div className="flex-1 overflow-y-auto">
        {list.map((c) => (
          <div key={c.id} className={`px-3 py-2 border-b border-brand-border/50 cursor-pointer ${selected===c.id ? "bg-brand-neutral" : "hover:bg-gray-50"}`} onClick={()=>onSelect(c.id)}>
            <div className="flex items-center justify-between gap-2">
              <div className="truncate text-sm">{c.title}</div>
              <div className="flex items-center gap-2 text-slate-400">
                <button onClick={(e)=>{ e.stopPropagation(); rename(c.id); }} title="Rename"><Edit2 className="w-3.5 h-3.5" /></button>
                <button onClick={(e)=>{ e.stopPropagation(); del(c.id); }} title="Delete"><Trash2 className="w-3.5 h-3.5" /></button>
              </div>
            </div>
            <div className="text-[11px] text-slate-500">Updated {new Date(c.updatedat).toLocaleString()}</div>
          </div>
        ))}
      </div>
    </aside>
  );
}
