"use client";

import { useEffect, useRef, useState } from "react";
import { Send, Copy, Loader2, ThumbsUp, ThumbsDown } from "lucide-react";

const AUTO = { key: "auto", title: "Auto (choose for me)" };
const CONSULTANTS = [
  { key: "classification", title: "Tariff Classification Consultant", brief: "Suggest HS codes with reasoning." },
  { key: "dutyTaxes", title: "Duty & Taxes Consultant", brief: "Estimate MFN/FTA duty, taxes, and fees." },
  { key: "fta", title: "FTA Eligibility Consultant", brief: "Check rules of origin and proofs." },
  { key: "routing", title: "Routing & Incoterms Consultant", brief: "Optimize routes and Incoterms." },
  { key: "landedCost", title: "Landed Cost Consultant", brief: "Build landed cost breakdowns." },
  { key: "docs", title: "Documentation Consultant", brief: "List required forms and timelines." },
  { key: "compliance", title: "Compliance & Red Flags", brief: "Flag licensing and restricted-party risks." },
  { key: "broker", title: "Broker Handoff Consultant", brief: "Prep broker-ready briefs." },
  { key: "rulings", title: "HS Ruling Research", brief: "Surface similar rulings and outcomes." },
  { key: "enrichment", title: "Product Data Enrichment", brief: "Elicit and structure product specs." },
  { key: "country", title: "Country-Specific Advisor", brief: "Country pair quirks and paperwork." },
  { key: "audit", title: "Audit & Recordkeeping", brief: "Retention and audit readiness." }
];

type Msg = { id?: string; role: "user" | "assistant"; content: string };

export default function ChatBox({ conversationId, clientId }: { conversationId?: string; clientId: string; }) {
  const [q, setQ] = useState("");
  const [loading, setLoading] = useState(false);
  const [selected, setSelected] = useState<string>(AUTO.key);
  const [msgs, setMsgs] = useState<Msg[]>([
    { role: "assistant", content: "I’m your SaveTariff AI Consultant. Ask about HS codes, duties, FTAs, documents, routing, or landed cost." }
  ]);

  const boxRef = useRef<HTMLDivElement>(null);
  useEffect(() => { boxRef.current?.scrollTo({ top: boxRef.current.scrollHeight, behavior: "smooth" }); }, [msgs, loading]);

  // Load messages on convo change
  useEffect(() => {
    (async () => {
      if (!conversationId) return;
      const res = await fetch(`/api/conversations/${conversationId}/messages?clientId=${clientId}`);
      const data = await res.json();
      if (Array.isArray(data) && data.length) setMsgs(data.map((m:any)=>({ id: m.id, role: m.role, content: m.content })));
      else setMsgs([{ role: "assistant", content: "I’m your SaveTariff AI Consultant. Ask about HS codes, duties, FTAs, documents, routing, or landed cost." }]);
    })();
  }, [conversationId, clientId]);

  async function send() {
    if (!q.trim() || loading || !conversationId) return;
    const userText = q.trim();
    setQ("");
    setMsgs((m) => [...m, { role: "user", content: userText }, { role: "assistant", content: "" }]);
    setLoading(true);

    try {
      const resp = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userMessage: userText, consultantKey: selected, conversationId, clientId })
      });

      const reader = resp.body!.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });

        const events = buffer.split("\n\n");
        buffer = events.pop() || "";

        for (const evt of events) {
          if (!evt.startsWith("data:")) continue;
          const data = evt.slice(5).trim();
          if (data === "[DONE]") {
            setLoading(false);
            return;
          }
          try {
            const obj = JSON.parse(data);
            if (obj.type === "response.output_text.delta") {
              setMsgs((m) => {
                const copy = [...m];
                const last = copy[copy.length - 1];
                if (last?.role === "assistant") last.content += obj.delta || "";
                return copy;
              });
            } else if (obj.type === "message.id") {
              setMsgs((m) => {
                const copy = [...m];
                const last = copy[copy.length - 1];
                if (last?.role === "assistant") last.id = obj.id;
                return copy;
              });
            }
          } catch {}
        }
      }
    } catch {
      setMsgs((m) => [...m, { role: "assistant", content: "Network error. Please try again." }]);
      setLoading(false);
    }
  }

  async function feedback(messageId?: string, rating?: "up" | "down") {
    if (!messageId) return;
    await fetch("/api/feedback", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ messageId, rating, clientId })
    });
  }

  function copyLast() {
    const last = [...msgs].reverse().find((m) => m.role === "assistant");
    if (last) navigator.clipboard.writeText(last.content);
  }

  const active = selected === AUTO.key ? AUTO : CONSULTANTS.find(c => c.key === selected) || AUTO;

  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-6 space-y-3">
      <div className="card p-3 flex flex-col sm:flex-row items-stretch sm:items-center gap-3 justify-between">
        <div className="flex-1">
          <label className="text-xs uppercase text-slate-500">AI Consultant</label>
          <select
            value={selected}
            onChange={(e) => setSelected(e.target.value)}
            className="mt-1 w-full border border-brand-border rounded-xl px-3 py-2 bg-white"
          >
            <option value={AUTO.key}>{AUTO.title}</option>
            {CONSULTANTS.map((c) => (
              <option key={c.key} value={c.key}>{c.title}</option>
            ))}
          </select>
        </div>
        <div className="flex-[2] text-sm text-slate-600">
          <div className="font-medium text-brand-navy">{active.title}</div>
          <div>{(CONSULTANTS.find(c=>c.key===selected)||CONSULTANTS[0]).brief}</div>
        </div>
        <div className="flex items-center gap-2">
          {conversationId && (
            <>
              <a href={`/api/conversations/${conversationId}/export?format=pdf&clientId=${clientId}`} className="btn btn-outline text-xs">Export PDF</a>
              <a href={`/api/conversations/${conversationId}/export?format=md&clientId=${clientId}`} className="btn btn-outline text-xs">Export MD</a>
            </>
          )}
        </div>
      </div>

      <div className="card p-0 overflow-hidden">
        <div ref={boxRef} className="h-[60vh] overflow-y-auto p-4 sm:p-6 space-y-4 bg-white">
          {msgs.map((m, i) => (
            <div key={i} className={`flex flex-col ${m.role === "user" ? "items-end" : "items-start"}`}>
              <div className={`max-w-[85%] rounded-2xl px-4 py-2 text-sm leading-relaxed
                ${m.role === "user" ? "bg-brand-navy text-white" : "bg-gray-100 text-slate-800"}`}>
                {m.content}
              </div>
              {m.role === "assistant" && m.id && (
                <div className="mt-1 flex items-center gap-3 text-xs text-slate-500">
                  <button onClick={() => feedback(m.id, "up")} className="inline-flex items-center gap-1 hover:text-brand-navy">
                    <ThumbsUp className="w-3.5 h-3.5" /> Helpful
                  </button>
                  <button onClick={() => feedback(m.id, "down")} className="inline-flex items-center gap-1 hover:text-brand-red">
                    <ThumbsDown className="w-3.5 h-3.5" /> Needs work
                  </button>
                </div>
              )}
            </div>
          ))}
          {loading && (
            <div className="flex items-center gap-2 text-slate-500 text-sm">
              <Loader2 className="w-4 h-4 animate-spin" /> streaming...
            </div>
          )}
        </div>
        <div className="border-t border-brand-border p-3 flex items-center gap-2">
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && send()}
            placeholder="Ask about duty rates, HS codes, documents, FTAs…"
            className="flex-1 border border-brand-border rounded-xl px-3 py-2 outline-none focus:ring-2 focus:ring-brand-navy/30"
          />
          <button onClick={send} className="btn btn-primary inline-flex gap-2">
            <Send className="w-4 h-4" /> Send
          </button>
          <button onClick={copyLast} title="Copy last answer" className="btn btn-outline">
            <Copy className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
