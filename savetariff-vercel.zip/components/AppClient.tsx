"use client";

import { useEffect, useState } from "react";
import Sidebar from "@/components/Sidebar";
import ChatBox from "@/components/ChatBox";

function getClientId() {
  const k = "st_client_id";
  let id = localStorage.getItem(k);
  if (!id) { id = crypto.randomUUID(); localStorage.setItem(k, id); }
  return id;
}

export default function AppClient() {
  const [convoId, setConvoId] = useState<string | undefined>(undefined);
  const [clientId, setClientId] = useState<string>("");

  useEffect(() => {
    setClientId(getClientId());
  }, []);

  useEffect(() => {
    if (!clientId) return;
    (async () => {
      const res = await fetch(`/api/conversations?clientId=${clientId}`);
      const data = await res.json();
      if (data?.length) setConvoId(data[0].id);
      else {
        // create initial conversation
        const r = await fetch(`/api/conversations?clientId=${clientId}`, {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ title: "New conversation" })
        });
        const j = await r.json();
        setConvoId(j.id);
      }
    })();
  }, [clientId]);

  if (!clientId) return null;

  return (
    <div className="h-[calc(100vh-64px)] grid grid-cols-1 sm:grid-cols-[18rem_1fr]">
      <Sidebar selected={convoId} onSelect={setConvoId} clientId={clientId} />
      <div className="overflow-hidden">
        <ChatBox conversationId={convoId} clientId={clientId} />
      </div>
    </div>
  );
}
