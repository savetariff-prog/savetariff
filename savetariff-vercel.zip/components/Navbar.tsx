import Link from "next/link";

export default function Navbar() {
  return (
    <header className="sticky top-0 z-40 backdrop-blur border-b border-brand-border bg-white/70">
      <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-3">
          <img src="/logo.png" alt="SaveTariff logo" className="h-8 w-auto" />
          <span className="font-semibold text-brand-navy text-lg">SaveTariff</span>
        </Link>
        <nav className="hidden sm:flex items-center gap-6 text-sm">
          <Link className="hover:opacity-80" href="/pricing">Pricing</Link>
          <Link className="hover:opacity-80" href="/app">App</Link>
        </nav>
      </div>
    </header>
  );
}
