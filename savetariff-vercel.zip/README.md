# SaveTariff — Vercel-ready (no-CLI setup)

## One-time setup (Vercel)
1) Create a new project in Vercel and upload this folder (or connect a repo).
2) Add **Vercel Postgres** (Storage → Add → Postgres). In **Project → Settings → Environment Variables** set:
   - `DATABASE_URL` = **POSTGRES_PRISMA_URL** from your Postgres resource (paste the value).
   - `OPENAI_API_KEY` = your OpenAI key.
3) Deploy. On first request the app auto-creates tables.

## Local dev (optional)
```
npm install
npm run dev
```
Set `.env.local`:
```
DATABASE_URL=postgresql://USER:PASS@HOST:PORT/DB?sslmode=require
OPENAI_API_KEY=sk-...
```

## Features
- Streaming chat via OpenAI **Responses API**
- 12 **AI Consultants** + Auto selector
- Conversation list (create/rename/delete)
- Per-message feedback (👍/👎)
- Export conversation to **PDF** or **Markdown**
- Auto DB setup (no migrations required)

**Note:** For smart semantic memory (pgvector), enable `CREATE EXTENSION vector;` in your DB and extend the schema. This build stores embeddings JSON-only by default.
