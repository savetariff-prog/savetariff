import type { Config } from "tailwindcss";

export default {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        brand: {
          navy: "#002049",
          red: "#921417",
          extra: "#000522",
          accent: "#790000",
          neutral: "#F7F8FA",
          border: "#E5E7EB"
        }
      },
      boxShadow: {
        soft: "0 8px 30px rgba(0,0,0,0.06)"
      }
    }
  },
  plugins: []
} satisfies Config;
