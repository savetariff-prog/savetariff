import { q } from "@/lib/db";

let initialized = false;
export async function ensureDb() {
  if (initialized) return;
  try {
    // Extensions (best-effort)
    await q(`CREATE EXTENSION IF NOT EXISTS "uuid-ossp";`).catch(()=>{});
    await q(`CREATE EXTENSION IF NOT EXISTS pgcrypto;`).catch(()=>{});
    await q(`CREATE EXTENSION IF NOT EXISTS vector;`).catch(()=>{});

    await q(`
      CREATE TABLE IF NOT EXISTS conversations (
        id TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
        client_id TEXT NOT NULL,
        title TEXT NOT NULL DEFAULT 'Untitled conversation',
        archived BOOLEAN NOT NULL DEFAULT false,
        consultant_key TEXT,
        createdAt TIMESTAMPTZ NOT NULL DEFAULT now(),
        updatedAt TIMESTAMPTZ NOT NULL DEFAULT now()
      );`);

    await q(`
      CREATE TABLE IF NOT EXISTS messages (
        id TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
        conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
        role TEXT NOT NULL,
        content TEXT NOT NULL,
        createdAt TIMESTAMPTZ NOT NULL DEFAULT now(),
        embeddingjson JSONB
      );`);

    await q(`
      CREATE TABLE IF NOT EXISTS feedback (
        id TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
        client_id TEXT NOT NULL,
        message_id TEXT NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
        rating TEXT NOT NULL,
        notes TEXT,
        createdAt TIMESTAMPTZ NOT NULL DEFAULT now()
      );`);

    await q(`CREATE INDEX IF NOT EXISTS idx_messages_convo ON messages(conversation_id);`);
    await q(`CREATE INDEX IF NOT EXISTS idx_messages_created ON messages(createdAt);`);
    initialized = true;
  } catch (e) {
    console.error("[ensureDb] setup error:", e);
  }
}
