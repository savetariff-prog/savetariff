import { Pool } from "pg";

const connectionString = process.env.DATABASE_URL;
if (!connectionString) {
  console.warn("[db] DATABASE_URL not set. App routes depending on DB will fail until you set it.");
}

export const pool = new Pool({
  connectionString,
  max: 3,
  ssl: { rejectUnauthorized: false }
});

export async function q(text: string, params: any[] = []) {
  const client = await pool.connect();
  try {
    return await client.query(text, params);
  } finally {
    client.release();
  }
}
