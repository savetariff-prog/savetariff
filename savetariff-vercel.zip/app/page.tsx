import Link from "next/link";

export default function Home() {
  return (
    <div>
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-brand-navy via-[#011430] to-brand-extra opacity-90" />
        <div className="relative max-w-6xl mx-auto px-4 py-24 text-white">
          <img src="/logo.png" alt="SaveTariff" className="h-10 w-auto mb-6 opacity-95" />
          <h1 className="text-4xl sm:text-6xl font-semibold tracking-tight">
            Save import duty. <span className="text-brand-red">Ship smarter.</span>
          </h1>
          <p className="mt-4 max-w-2xl text-slate-200">
            Subscribe to SaveTariff and chat with AI <strong>Consultants</strong> that identify HS codes,
            estimate duties, surface FTAs, and flag compliance risks — streamed to you in real time.
          </p>
          <div className="mt-8 flex gap-3">
            <Link href="/app" className="btn btn-primary">Open the app</Link>
            <Link href="/pricing" className="btn btn-outline">See pricing</Link>
          </div>
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-4 py-14">
        <h2 className="text-2xl font-semibold text-brand-navy mb-4">12 AI Consultants</h2>
        <p className="text-slate-600 mb-6">Pick a consultant in the app or just describe your need — we’ll route it.</p>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {[
            ["Tariff Classification Consultant", "Suggests HS codes with reasoning and confidence."],
            ["Duty & Taxes Consultant", "Estimates MFN/FTA duty, taxes, and fees for shipments."],
            ["FTA Eligibility Consultant", "Checks preference programs and rules of origin fit."],
            ["Routing & Incoterms Consultant", "Optimizes routes and Incoterms to cut landed cost."],
            ["Landed Cost Consultant", "Builds landed-cost breakdowns with assumptions."],
            ["Documentation Consultant", "Lists required forms, certificates, and timelines."],
            ["Compliance & Red Flags", "Flags licensing, ECCN/ITAR, and restricted-party risks."],
            ["Broker Handoff Consultant", "Preps broker-ready briefs with key shipment data."],
            ["HS Ruling Research", "Finds relevant rulings/patterns to support decisions."],
            ["Product Data Enrichment", "Structures product specs needed for classification."],
            ["Country-Specific Advisor", "Country pair guidance (US↔India, US↔EU, etc.)."],
            ["Audit & Recordkeeping", "Outlines retention rules and audit preparation."]
          ].map(([title, desc]) => (
            <div key={title} className="card p-5 hover:shadow-lg transition-shadow">
              <h3 className="font-semibold text-brand-navy">{title}</h3>
              <p className="text-slate-600 mt-2 text-sm">{desc}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
