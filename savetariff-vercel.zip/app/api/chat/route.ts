export const runtime = "nodejs";

import { NextRequest } from "next/server";
import { ensureDb } from "@/lib/setup";
import { q } from "@/lib/db";

const SYSTEM_PROMPT = `You are SaveTariff — “Save import duty. Ship smarter.”
Act as 12 specialized AI Consultants (classification, duty/tax, FTA, routing & Incoterms, landed cost, documentation,
compliance, broker handoff, ruling research, data enrichment, country-specific advice, audit/recordkeeping).
Ask for missing context (product, origin/destination, HS if known, Incoterms, value/qty/weight, mode).
If assumptions are needed, state them before advising. Focus primarily on U.S. import/export.`;

export async function POST(req: NextRequest) {
  await ensureDb();
  const { userMessage, consultantKey, conversationId, clientId } = await req.json();

  if (!process.env.OPENAI_API_KEY) {
    return new Response("OPENAI_API_KEY missing", { status: 500 });
  }

  // Basic ownership check
  const owner = await q(`SELECT 1 FROM conversations WHERE id=$1 AND client_id=$2`, [conversationId, clientId]);
  if (!owner.rowCount) {
    return new Response("Conversation not found", { status: 404 });
  }

  // Save user message
  const userRow = await q(`INSERT INTO messages (conversation_id, role, content) VALUES ($1, 'user', $2) RETURNING id`, [conversationId, String(userMessage ?? "")]);

  // Get recent history
  const history = await q(`SELECT role, content FROM messages WHERE conversation_id=$1 ORDER BY createdAt ASC LIMIT 20`, [conversationId]);

  const consultantNote = consultantKey && consultantKey !== "auto"
    ? `\n\nSpecialization: ${consultantKey}`
    : "";

  // Build input in Responses API format
  const input: any[] = [
    { role: "system", content: [{ type: "text", text: SYSTEM_PROMPT + consultantNote }] },
    ...history.rows.map((m: any) => ({
      role: m.role === "user" ? "user" : "assistant",
      content: [{ type: m.role === "user" ? "input_text" : "text", text: m.content }]
    }))
  ];

  const upstream = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: "gpt-4o-mini",
      stream: true,
      input
    })
  });

  // Stream back to client; accumulate assistant text to save after completion
  const stream = new ReadableStream({
    async start(controller) {
      let assistantText = "";
      const reader = upstream.body!.getReader();
      const decoder = new TextDecoder();

      function line(obj: any) { return `data: ${JSON.stringify(obj)}\n\n`; }

      controller.enqueue(line({ type: "conversation.id", id: conversationId }));

      async function pump() {
        const { value, done } = await reader.read();
        if (done) {
          const saved = await q(
            `INSERT INTO messages (conversation_id, role, content) VALUES ($1, 'assistant', $2) RETURNING id`,
            [conversationId, assistantText]
          );
          controller.enqueue(line({ type: "message.id", id: saved.rows[0].id }));
          controller.enqueue("data: [DONE]\n\n");
          controller.close();
          return;
        }
        const chunk = decoder.decode(value, { stream: true });
        controller.enqueue(chunk);

        for (const evt of chunk.split("\n\n")) {
          if (!evt.startsWith("data:")) continue;
          const data = evt.slice(5).trim();
          if (!data || data === "[DONE]") continue;
          try {
            const obj = JSON.parse(data);
            if (obj.type === "response.output_text.delta" && obj.delta) assistantText += obj.delta;
          } catch {}
        }
        await pump();
      }
      await pump();
    }
  });

  const headers = new Headers({
    "Content-Type": "text/event-stream; charset=utf-8",
    "Cache-Control": "no-cache, no-transform",
    "Connection": "keep-alive",
    "X-Accel-Buffering": "no"
  });
  return new Response(stream, { headers });
}
