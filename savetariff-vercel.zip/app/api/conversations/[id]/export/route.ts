export const runtime = "nodejs";

import { NextRequest } from "next/server";
import { ensureDb } from "@/lib/setup";
import { q } from "@/lib/db";
import path from "path";
import fs from "fs";

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  await ensureDb();
  const id = params.id;
  const clientId = req.nextUrl.searchParams.get("clientId")!;
  const format = (new URL(req.url).searchParams.get("format") || "pdf").toLowerCase();

  const convo = await q(`SELECT id, title FROM conversations WHERE id=$1 AND client_id=$2`, [id, clientId]);
  if (!convo.rowCount) return new Response("Not found", { status: 404 });

  const msgs = await q(`SELECT role, content, createdAt FROM messages WHERE conversation_id=$1 ORDER BY createdAt ASC`, [id]);
  if (!msgs.rowCount) return new Response("No messages", { status: 404 });

  const header = `# ${convo.rows[0].title}\n\nExported: ${new Date().toISOString()}\n\n---\n\n`;
  const body = msgs.rows.map((m: any) => `**[${new Date(m.createdat).toISOString()}] ${String(m.role).toUpperCase()}:**\n\n${m.content}`).join("\n\n---\n\n");
  const md = header + body + "\n";

  if (format === "md") {
    return new Response(md, {
      headers: {
        "Content-Type": "text/markdown; charset=utf-8",
        "Content-Disposition": `attachment; filename="conversation-${id}.md"`
      }
    });
  }

  const PDFDocument = (await import("pdfkit")).default;
  const doc = new PDFDocument({ size: "A4", margins: { top: 50, bottom: 50, left: 50, right: 50 } });
  const chunks: Buffer[] = [];
  const stream: any = doc as any;
  stream.on("data", (c: Buffer) => chunks.push(c));
  const endPromise: Promise<Buffer> = new Promise((resolve) => { stream.on("end", () => resolve(Buffer.concat(chunks))); });

  try {
    const logoPath = path.join(process.cwd(), "public", "logo.png");
    if (fs.existsSync(logoPath)) {
      doc.image(logoPath, 50, 40, { width: 90 });
    }
  } catch {}
  doc.fillColor("#002049").fontSize(18).text(convo.rows[0].title, 150, 45);
  doc.moveDown(2);
  doc.fillColor("#000000").fontSize(10).text(`Exported: ${new Date().toLocaleString()}`);
  doc.moveDown();

  doc.fontSize(12);
  for (const m of msgs.rows) {
    doc.fillColor("#921417").font("Times-Bold").text(String(m.role).toUpperCase(), { continued: true });
    doc.fillColor("#666666").font("Times-Roman").text(`  •  ${new Date(m.createdat).toLocaleString()}`);
    doc.moveDown(0.5);
    doc.fillColor("#111111").font("Times-Roman").text(m.content, { width: 500 });
    doc.moveDown();
    doc.moveTo(50, doc.y).lineTo(545, doc.y).strokeColor("#E5E7EB").stroke();
    doc.moveDown();
  }
  doc.end();
  const pdf = await endPromise;

  return new Response(pdf, {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="conversation-${id}.pdf"`
    }
  });
}
