export const runtime = "nodejs";

import { NextRequest, NextResponse } from "next/server";
import { ensureDb } from "@/lib/setup";
import { q } from "@/lib/db";

export async function GET(req: NextRequest, { params }: { params: { id: string }}) {
  await ensureDb();
  const clientId = req.nextUrl.searchParams.get("clientId");
  const id = params.id;
  // basic ownership check
  const ok = await q(`SELECT 1 FROM conversations WHERE id=$1 AND client_id=$2`, [id, clientId]);
  if (!ok.rowCount) return NextResponse.json([], { status: 200 });
  const r = await q(`SELECT id, role, content, createdAt FROM messages WHERE conversation_id=$1 ORDER BY createdAt ASC`, [id]);
  return NextResponse.json(r.rows);
}
