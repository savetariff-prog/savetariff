export const runtime = "nodejs";

import { NextRequest, NextResponse } from "next/server";
import { ensureDb } from "@/lib/setup";
import { q } from "@/lib/db";

export async function PATCH(req: NextRequest, { params }: { params: { id: string }}) {
  await ensureDb();
  const clientId = req.nextUrl.searchParams.get("clientId");
  const id = params.id;
  const body = await req.json();
  if (typeof body.title === "string") {
    await q(`UPDATE conversations SET title=$1, updatedAt=now() WHERE id=$2 AND client_id=$3`, [body.title, id, clientId]);
  }
  return NextResponse.json({ ok: true });
}

export async function DELETE(req: NextRequest, { params }: { params: { id: string }}) {
  await ensureDb();
  const clientId = req.nextUrl.searchParams.get("clientId");
  const id = params.id;
  await q(`DELETE FROM conversations WHERE id=$1 AND client_id=$2`, [id, clientId]);
  return NextResponse.json({ ok: true });
}
