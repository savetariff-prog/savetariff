export const runtime = "nodejs";

import { NextRequest, NextResponse } from "next/server";
import { ensureDb } from "@/lib/setup";
import { q } from "@/lib/db";

export async function GET(req: NextRequest) {
  await ensureDb();
  const clientId = req.nextUrl.searchParams.get("clientId");
  if (!clientId) return NextResponse.json([], { status: 200 });
  const r = await q(`SELECT id, title, updatedAt FROM conversations WHERE client_id=$1 AND archived=false ORDER BY updatedAt DESC`, [clientId]);
  return NextResponse.json(r.rows);
}

export async function POST(req: NextRequest) {
  await ensureDb();
  const clientId = req.nextUrl.searchParams.get("clientId");
  const body = await req.json();
  const title = body?.title || "Untitled conversation";
  const r = await q(`INSERT INTO conversations (client_id, title) VALUES ($1, $2) RETURNING id, title`, [clientId, title]);
  return NextResponse.json(r.rows[0], { status: 201 });
}
