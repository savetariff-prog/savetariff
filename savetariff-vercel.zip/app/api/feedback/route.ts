export const runtime = "nodejs";

import { NextRequest, NextResponse } from "next/server";
import { ensureDb } from "@/lib/setup";
import { q } from "@/lib/db";

export async function POST(req: NextRequest) {
  await ensureDb();
  const { messageId, rating, clientId, notes } = await req.json();
  if (!messageId || !rating || !clientId) return NextResponse.json({ error: "bad request" }, { status: 400 });
  await q(`INSERT INTO feedback (client_id, message_id, rating, notes) VALUES ($1, $2, $3, $4)`, [clientId, messageId, rating, notes || null]);
  return NextResponse.json({ ok: true });
}
