"use client";
import AppClient from "@/components/AppClient";
export default function Page(){ return <AppClient/> }
