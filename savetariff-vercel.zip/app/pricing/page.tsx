export default function Pricing(){
  return (
    <div className="max-w-5xl mx-auto px-4 py-12">
      <h1 className="text-3xl font-semibold text-brand-navy mb-6">Pricing</h1>
      <p className="text-slate-600">Hook your Stripe Pricing Table here when you're ready.</p>
    </div>
  );
}
