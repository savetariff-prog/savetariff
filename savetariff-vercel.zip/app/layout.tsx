import "./globals.css";
import Navbar from "@/components/Navbar";

export const metadata = {
  title: "SaveTariff",
  description: "Save import duty. Ship smarter."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-brand-neutral min-h-screen">
        <Navbar />
        {children}
      </body>
    </html>
  );
}
